INSERT INTO alameda_county VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)

SELECT `date` FROM `alameda_county` ORDER BY `date` DESC LIMIT 1

SELECT "totalcountconfirmed", "newcountdeaths", "totalcountdeaths", "county", "newcountconfirmed", "date" FROM "926fd08f-cc91-4828-af38-bd45de97f8c3" WHERE 'date' > '2020-07-24'

/* SELECT `cases` FROM `california` WHERE `county` IN ('') */