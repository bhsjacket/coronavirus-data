<?php

echo file_get_contents('http:https://multimedia.berkeleyhighjacket.com/2020/coronavirus/finals/alameda_county/apex.php');